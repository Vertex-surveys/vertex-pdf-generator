#!/bin/bash
echo "Starting Vertex PDF Generator..."
node src/server.js
